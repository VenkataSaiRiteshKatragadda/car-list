package com.example.listapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class CarDetailsActivity extends AppCompatActivity {
    TextView carType;
    EditText dailyRate;
    ImageView carImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_details);
        carType =findViewById(R.id.tvType);
        dailyRate=findViewById(R.id.etRate);
        carImg=findViewById(R.id.imageView2);

        carType.setText(MainActivity.selectedCarType);
        dailyRate.setText(String.format("%.2f",MainActivity.selectedCarRate));
        carImg.setImageResource(MainActivity.selectedCarImg);
    }
}
