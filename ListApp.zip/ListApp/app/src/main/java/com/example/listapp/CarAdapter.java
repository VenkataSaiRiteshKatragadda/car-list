package com.example.listapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

//This class to customize the list view adapter
public class CarAdapter extends BaseAdapter {
    private ArrayList<Car> carData; //the car details
    private LayoutInflater layoutInflater; //we need it to initialize objects in the XML file

    public CarAdapter(Context context,ArrayList<Car> carData) {
        this.carData = carData;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() { //returns the number of items in the list
        return carData.size();
    }

    @Override
    public Object getItem(int i) {//returns the list item
        return carData.get(i);
    }

    @Override
    public long getItemId(int i) {//returns the row index
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //creating a view to show the xml objects
        ViewHolder holder;

        if(view==null){
            //creating the view from the list_row XML file using the inflater
            view =layoutInflater.inflate(R.layout.list_row,null);
            holder=new ViewHolder();
            //initializing the objects by matching them with the XML objects
            holder.tvCarType=view.findViewById(R.id.tvType);
            holder.tvDailyRate=view.findViewById(R.id.tvRate);
            holder.carImage=view.findViewById(R.id.imageView);
            view.setTag(holder);

        }
        else
            holder = (ViewHolder) view.getTag();
        //set Values for the objects to be displayed in the list view row
        holder.tvCarType.setText(carData.get(i).getCarType());
        holder.tvDailyRate.setText(String.format("%.2f",carData.get(i).getDailyRate()));
        holder.carImage.setImageResource(carData.get(i).getCarImg());
        return view;
    }

    //class to declare the objects of the list row
    static class ViewHolder{
        TextView tvCarType;
        TextView tvDailyRate;
        ImageView carImage;
    }
}
