package com.example.listapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
    //Declare the list view object
    ListView carListView;
    //Create the car list
    ArrayList<Car> cars = new ArrayList<Car>();
    String carMake[]={"Honda","Nissan","Toyota","Ford"};
    Spinner sp;
    ArrayList <Car> selectedCars = new ArrayList<Car>();
    public static String selectedCarType;
    public static double selectedCarRate;
    public static int selectedCarImg;

    //A method to fill the care details
    public void fillCarData(){
        cars.add(new Car("Honda","Accord",50,R.drawable.accord));
        cars.add(new Car("Nissan","Altima",55,R.drawable.altima));
        cars.add(new Car("Toyota","Camry",48,R.drawable.camry));
        cars.add(new Car("Toyota","Corolla",37,R.drawable.corolla));
        cars.add(new Car("Ford","Focus",38,R.drawable.focus));
        cars.add(new Car("Nissan","Sunny",32,R.drawable.sunny));
        cars.add(new Car("Nissan","Tida",28,R.drawable.tida));




    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillCarData();//calling the method
        carListView=findViewById(R.id.lvCars);


        //initialize the spinner
        sp=findViewById(R.id.spMake);
        //Create the adapter for the spinner
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,carMake);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);//fill the spinner from the adapter

        sp.setOnItemSelectedListener(this);
        carListView.setOnItemClickListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

            selectedCars.clear(); //selectedCars is an Array list of cars which belong to the selected car make form the spinner
            String make = carMake[i];//carMake is an array of cars makes {"Honda","Nissan","Toyota","Ford"}
            for (int j = 0; j < cars.size(); j++) //cars is an Array list of all cars details
                if (cars.get(j).getCarMake().equals(make))
                    selectedCars.add(cars.get(j));
            carListView.setAdapter(new CarAdapter(this, selectedCars));




    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        selectedCarType=selectedCars.get(i).getCarType();
        selectedCarRate=selectedCars.get(i).getDailyRate();
        selectedCarImg=selectedCars.get(i).getCarImg();
        Intent intent=new Intent(this,CarDetailsActivity.class);
        startActivity(intent);

    }
}
