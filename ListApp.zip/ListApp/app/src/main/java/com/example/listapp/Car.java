package com.example.listapp;

public class Car {
    private String carMake;
    private String carType;
    private double dailyRate;
    private int carImg;

    public Car(String carMake, String carType, double dailyRate, int carImg) {
        this.carMake = carMake;
        this.carType = carType;
        this.dailyRate = dailyRate;
        this.carImg = carImg;
    }

    public String getCarMake() {
        return carMake;
    }

    public void setCarMake(String carMake) {
        this.carMake = carMake;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    public int getCarImg() {
        return carImg;
    }

    public void setCarImg(int carImg) {
        this.carImg = carImg;
    }
}
